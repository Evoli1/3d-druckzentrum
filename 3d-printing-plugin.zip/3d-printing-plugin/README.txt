Install and activate Plugin WP Mail SMTP
Strato SMTP:
SMTP Host: smtp.strato.com
SMTP Port: 587 (TLS) or (preferable) 465 (SSL) 
Username: Email address on Strato.
Password:
